import React from 'react';

const Favoritos = () => {
  return (
    <div>
      <h1>Página de Favoritos</h1>
    </div>
  );
};

export default Favoritos;
